import sys
import os

from PyQt5.QtWidgets import QApplication, QMainWindow,QTreeWidgetItem, QLabel,QFileDialog,QDockWidget,QFileSystemModel,QGraphicsScene,QMessageBox,QWidget,QGraphicsScene,QHBoxLayout,QVBoxLayout,QSpacerItem,QSizePolicy
from enum import Enum  
from PyQt5.QtCore import  pyqtSlot, Qt, QDir, QFileInfo
from PyQt5.QtGui import  QIcon
from ui_MainWindow import Ui_MainWindow

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

def readpath():
   with open('paths.txt') as f:
      temp1 = f.readlines() 
   
   agent_num = len(temp1)

   length = np.zeros(agent_num,dtype = np.int32)

   for i in range(agent_num):
      temp2 = temp1[i].split()
      temp3 = temp2[5:]
      length[i] = len(temp3)

   max_length = int(length.max()*1.1)

   path = np.zeros((agent_num,max_length,2),dtype = np.int32)
 
   for i in range(agent_num):
      temp2 = temp1[i].split()
      temp3 = temp2[5:]

      for j in range(max_length):

            last_position = temp3[length[i]-1].split(',')
            last_x = int(last_position[0])
            last_y = int(last_position[1])

            if(j < length[i]):
               num = temp3[j].split(',')
               path[i,j,0] = int(num[0])
               path[i,j,1] = int(num[1])

            else:
               path[i,j,0] = last_x
               path[i,j,1] = last_y

   return path,max_length,agent_num


class TreeItemType(Enum):    
   itTopItem=1001    
   itGroupItem=1002  
   itInstanceItem=1003  

class TreeColNum(Enum):   
   colItem=0         
   colItemType=1     

class Figure_Canvas(FigureCanvas):   

   def __init__(self, parent=None,width=5, height=8, dpi=100):
      fig = Figure(figsize=(width, height), dpi=100)  
      # fig = Figure(tight_layout=True)

      FigureCanvas.__init__(self, fig) 
      self.setParent(parent)
      self.axes = fig.add_subplot(111) 

      self.fig, self.ax = plt.subplots() 

class QmyMainWindow(QMainWindow):
   def __init__(self, parent=None):
      super().__init__(parent)    
      self.ui = Ui_MainWindow()     
      self.ui.setupUi(self)       

      self.itemFlags=(Qt.ItemIsSelectable | Qt.ItemIsUserCheckable
                     | Qt.ItemIsEnabled | Qt.ItemIsAutoTristate)  
      self.setCentralWidget(self.ui.stackedWidget)
      self.__iniTree()
      
      self.ui.dockWidget.setFeatures(QDockWidget.AllDockWidgetFeatures)
      self.resizeDocks([self.ui.dockWidget],[300],Qt.Horizontal)

      self.ui.treeFiles.setColumnWidth(0, 200)
      self.ui.treeFiles.setColumnWidth(1, 100)
      self.ui.dockWidget.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
      
      self.ui.btnRun.clicked.connect(self.do_run)
      self.ui.btnReturn.clicked.connect(self.do_return)
      self.ui.comboBox.setCurrentIndex(4)

      self.ui.spinBox_TimeLimit.setValue(30)
      self.ui.doubleSpinBoxSub.setValue(1.01)
      self.ui.spinBox_AgentNum.setValue(10)

      self.instancePath = "./instances"

      self.pyPath = os.getcwd()
      self.canvas = Figure_Canvas()

      self.agent_num = ''
      self.max_length = ''
      self.path = ''

      self.agentcolorlist=[]
      self.colorlist = ['r','g','b','y','c','m','k','lightcoral','chocolate','gold','lawngreen','dodgerblue','hotpink','blueviolet','darkgrey']

      self.foldername = ''
      self.filename = ''
      self.mapname = ''
      self.agentnum = ''
      self.sub_fac = ''
      self.agentnum2019 = ''
      self.timeLimit = ''
      self.algorithm = ''


   def __iniTree(self):     
      self.ui.treeFiles.clear()
      icon= QIcon(":/images/icons/Documents.ico")

      root=QTreeWidgetItem(TreeItemType.itTopItem.value)
      root.setIcon(TreeColNum.colItem.value, icon)
      root.setText(TreeColNum.colItem.value,"Instances")
      root.setFlags(self.itemFlags)
      root.setCheckState(TreeColNum.colItem.value, Qt.Checked)

      root.setData(TreeColNum.colItem.value, Qt.UserRole,"")
      self.ui.treeFiles.addTopLevelItem(root)

      instances =["empty-32-32","random-32-32-10","den312d","warehouse-10-20-10-2-1"]
      childpaths = []
      child = []

      for i in range(len(instances)):
         childpaths.append("./instances/"+instances[i])
         
      for i in range(len(instances)):
         child.append(QmyMainWindow.addMyFolder(self,root,childpaths[i]))
         QmyMainWindow.addAllScenFile(self,child[i],childpaths[i])

      self.ui.stackedWidget.setCurrentIndex(0)
    
   def addMyFolder(self,root,path): 
      icon= QIcon(":/images/icons/open3.bmp")
      dirObj=QDir(path)             
      nodeText=dirObj.dirName()     
      child=QTreeWidgetItem(TreeItemType.itGroupItem.value)   
      child.setIcon(TreeColNum.colItem.value, icon)
      child.setText(TreeColNum.colItem.value,nodeText)        
      child.setText(TreeColNum.colItemType.value,"Folder")     
      child.setFlags(self.itemFlags)
      child.setCheckState(TreeColNum.colItem.value, Qt.Checked)

      child.setData(TreeColNum.colItem.value, Qt.UserRole,path)  
      root.addChild(child)
      root.setExpanded(True)  

      return child

   def addAllScenFile(self,root,path): 
      dirObj = QDir(path)
      dirObj.setFilter(QDir.Files|QDir.Hidden|QDir.NoSymLinks)
      dirObj.setNameFilters(['*.scen'])
 
      file_list = dirObj.entryList()
      
      for i in range(len(file_list)):
         fullFileName = file_list[i]        
         fileinfo = QFileInfo(fullFileName)
         nodeText = fileinfo.fileName()    

         item=QTreeWidgetItem(TreeItemType.itInstanceItem.value)    
         item.setText(TreeColNum.colItem.value, nodeText) 
         item.setText(TreeColNum.colItemType.value,"Instance")  
         item.setFlags(self.itemFlags)
         item.setCheckState(TreeColNum.colItem.value, Qt.Checked)

         item.setData(TreeColNum.colItem.value, Qt.UserRole,fullFileName)  
         root.addChild(item)            
   
   def getInstanceInfo(self,item):
      filename = item.data(TreeColNum.colItem.value, Qt.UserRole)
      
      folder = item.parent()
      foldername = folder.data(TreeColNum.colItem.value, Qt.UserRole)

      mapname = filename.split('-r')[0]+".map"     
      self.ui.stackedWidget.setCurrentIndex(1)

      self.filename = filename
      self.mapname = mapname
      self.foldername = foldername     


   def __displayInstance(self,item):   

      self.getInstanceInfo(item)
      self.ui.statusBar.showMessage(self.filename)   

      folder = item.parent()
      foldername = folder.data(TreeColNum.colItem.value, Qt.UserRole)


      self.ui.labInstanceName.setText(self.filename)
      self.ui.labMapName.setText(self.mapname)

      maxAgentNum = 0
      if(foldername == './instances/empty-32-32'):
         maxAgentNum = 512
      elif(foldername == './instances/random-32-32-10'):
         maxAgentNum = 461
      elif(foldername == './instances/den312d'):
         maxAgentNum = 1000
      elif(foldername == './instances/warehouse-10-20-10-2-1'):
         maxAgentNum = 1000       


      self.ui.labelAgentNum.setText("Number of agents：(0-"+str(maxAgentNum)+")")


   def update_points(self,step):
      scat = self.canvas.axes.scatter(self.path[:,0,0],self.path[:,0,1],c = self.agentcolorlist)  
      scat.set_offsets(self.path[:,step])
      return scat,


   def draw(self):
      with open('paths.txt') as f:
         temp1 = f.readlines() 
      
      if(temp1 == []):
         pass
      
      else:
         self.agent_num = readpath()[2]
         self.max_length = readpath()[1]
         self.path = readpath()[0]

         self.agentcolorlist=[]

         for i in range(self.agent_num):
            if(i < len(self.colorlist)):
               self.agentcolorlist.append(self.colorlist[i])
            else:
               self.agentcolorlist.append(self.colorlist[i%len(self.colorlist)])

         for i in range(self.agent_num):
            linecolor = self.agentcolorlist[i]
            self.canvas.axes.plot(self.path[i,:,0],self.path[i,:,1],color = linecolor,alpha=0.2) 
         
         time_interval = 5000/self.max_length
         self.ani = animation.FuncAnimation(self.canvas.figure, self.update_points, np.arange(0, self.max_length), interval=time_interval, blit=True)


   def showPath(self):
      with open('paths.txt') as f:
         temp1 = f.readlines() 
      
      if(temp1 == []):
         QMessageBox.information(self,"Reminder","Failed to find a solution, please change information and try again.")

      else:
         self.ui.stackedWidget.setCurrentIndex(2)
         if(self.ui.labInstanceName_2.text()!='abcde111111111111111111111111.scen'):
            self.setPage4()
         else:
            self.iniPage4()

   def do_run(self):
      item = self.ui.treeFiles.currentItem()
      self.getInstanceInfo(item)

      folder = item.parent()
      foldername = folder.data(TreeColNum.colItem.value, Qt.UserRole)

      os.chdir(self.pyPath)

      self.timeLimit = str(self.ui.spinBox_TimeLimit.value())
      self.agentnum = str(self.ui.spinBox_AgentNum.value())
      self.sub_fac = str(self.ui.doubleSpinBoxSub.value())
      self.algorithm = str(self.ui.comboBox.currentText())

      cmd =""
   
      if(self.algorithm == "MCBS"):
         cmd = "./eecbs -m "+ self.foldername + "/" + self.mapname + " -a " + self.foldername + "/" + self.filename + " -o results.csv --outputPaths=paths.txt -k "+ self.agentnum + " -t "+self.timeLimit + " --heuristic=Zero --prioritizingConflicts=0 --bypass=0 --rectangleReasoning=0 --corridorReasoning=0 --targetReasoning=0 --highLevelSolver=A*eps --suboptimality=1.0"

      elif(self.algorithm == "EMCBS"):
         cmd = "./eecbs -m "+ self.foldername + "/" + self.mapname + " -a " + self.foldername + "/" + self.filename + " -o results.csv --outputPaths=paths.txt -k "+ self.agentnum + " -t "+self.timeLimit + " --heuristic=Zero --prioritizingConflicts=0 --bypass=0 --rectangleReasoning=0 --corridorReasoning=0 --targetReasoning=0 --highLevelSolver=A*eps --suboptimality=" + self.sub_fac

      elif(self.algorithm == "EEMCBS"):
         cmd = "./eecbs -m "+ self.foldername + "/" + self.mapname + " -a " + self.foldername + "/" + self.filename + " -o results.csv --outputPaths=paths.txt -k "+ self.agentnum + " -t "+self.timeLimit + " --heuristic=Zero --prioritizingConflicts=0 --bypass=0 --rectangleReasoning=0 --corridorReasoning=0 --targetReasoning=0 --highLevelSolver=EES --suboptimality="+ self.sub_fac
   
      elif(self.algorithm == "EMCBS+"):
         cmd = "./eecbs -m "+ self.foldername + "/" + self.mapname + " -a " + self.foldername + "/" + self.filename + " -o results.csv --outputPaths=paths.txt -k "+ self.agentnum + " -t "+self.timeLimit+" --highLevelSolver=A*eps --suboptimality="+ self.sub_fac

      elif(self.algorithm == "EEMCBS+"):
         cmd = "./eecbs -m "+ self.foldername + "/" + self.mapname + " -a " + self.foldername + "/" + self.filename + " -o results.csv --outputPaths=paths.txt -k "+ self.agentnum + " -t "+self.timeLimit+" --suboptimality="+ self.sub_fac
         
     
      os.system(cmd)

      self.draw()
      self.showPath()


   def setPage4(self):
      self.ui.labInstanceName_2.setText(self.filename)
      self.ui.labMapName_2.setText(self.mapname)

      item = self.ui.treeFiles.currentItem()
      folder = item.parent()
      foldername = folder.data(TreeColNum.colItem.value, Qt.UserRole)

      if(foldername != self.instancePath+'/movingai_2019'):
         self.ui.labAgentNum_2.setText(self.agentnum)
      
      else:
         self.ui.labAgentNum_2.setText(self.agentnum2019)

      with open('results.csv') as f:
         lines = f.readlines()

      line = lines[-1].split(',')         
      priObj = line[3]
      secObj = line[4]

      self.ui.labPriObjVal.setText(str(priObj))
      self.ui.labSecObjVal.setText(str(secObj))


   def iniPage4(self):
      self.setPage4()
      self.vbox = QVBoxLayout()
      self.vbox.addWidget(self.ui.groupBox)

      self.hbox1 = QHBoxLayout()
      self.hbox1.addWidget(self.ui.labPriObj)
      self.hbox1.addWidget(self.ui.labPriObjVal)
      self.hbox1.addWidget(self.ui.labSecObj)
      self.hbox1.addWidget(self.ui.labSecObjVal)
      self.vbox.addLayout(self.hbox1)

      self.hbox2 = QHBoxLayout()
      self.spacer4_1 = QSpacerItem(20, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
      self.hbox2.addWidget(self.ui.labPath)
      self.hbox2.addItem(self.spacer4_1)
      self.vbox.addLayout(self.hbox2)

      self.vbox.addWidget(self.canvas)
      
      self.hbox2 = QHBoxLayout()
      self.spacer4_2 = QSpacerItem(20, 20, QSizePolicy.Expanding, QSizePolicy.Minimum)
      self.hbox2.addItem(self.spacer4_2)
      self.hbox2.addWidget(self.ui.btnReturn)

      self.vbox.addLayout(self.hbox2)
      self.ui.page_4.setLayout(self.vbox)


   def do_return(self):
      self.ani._stop()
      self.canvas.axes.cla()


      item = self.ui.treeFiles.currentItem()
      self.__displayInstance(item)


   def __changeItemCaption(self,item):
      title="*"+item.text(TreeColNum.colItem.value)
      item.setText(TreeColNum.colItem.value, title)
      if (item.childCount()>0):
         for i in range(item.childCount()):
            self.__changeItemCaption(item.child(i))


       
   @pyqtSlot()    
   def on_actTree_AddFolder_triggered(self):  
      dirStr=QFileDialog.getExistingDirectory()   
      if (dirStr == ""):
         return

      parItem=self.ui.treeFiles.currentItem()   
      if (parItem == None):
         parItem=self.ui.treeFiles.topLevelItem(0)

      icon= QIcon(":/images/icons/open3.bmp")

      dirObj=QDir(dirStr)     
      nodeText=dirObj.dirName()     

      item=QTreeWidgetItem(TreeItemType.itGroupItem.value)   
      item.setIcon(TreeColNum.colItem.value, icon)
      item.setText(TreeColNum.colItem.value,nodeText)       
      item.setText(TreeColNum.colItemType.value,"Group")    
      item.setFlags(self.itemFlags)
      item.setCheckState(TreeColNum.colItem.value, Qt.Checked)

      item.setData(TreeColNum.colItem.value, Qt.UserRole,dirStr)  
      parItem.addChild(item)
      parItem.setExpanded(True)  
        

   @pyqtSlot()    
   def on_actTree_AddFiles_triggered(self): 
      fileList,flt=QFileDialog.getOpenFileNames(self,
                     "Please choose a file","","Images(*.scen)")
     
      if (len(fileList)<1): 
         return

      item = self.ui.treeFiles.currentItem() 
      if (item.type()==TreeItemType.itInstanceItem.value): 
         parItem=item.parent()
      else:      
         parItem=item

      icon= QIcon(":/images/icons/31.ico")
      for i in range(len(fileList)):
         fullFileName=fileList[i]        
         fileinfo=QFileInfo(fullFileName)
         nodeText=fileinfo.fileName()    

         item=QTreeWidgetItem(TreeItemType.itInstanceItem.value)    
         item.setIcon(TreeColNum.colItem.value, icon)     
         item.setText(TreeColNum.colItem.value, nodeText)
         item.setText(TreeColNum.colItemType.value,"Image")  
         item.setFlags(self.itemFlags)
         item.setCheckState(TreeColNum.colItem.value, Qt.Checked)

         item.setData(TreeColNum.colItem.value, Qt.UserRole,fullFileName)  
         parItem.addChild(item)
            
      parItem.setExpanded(True) 


   @pyqtSlot()    
   def on_actTree_DeleteItem_triggered(self): 
      item =self.ui.treeFiles.currentItem()
      parItem=item.parent()
      parItem.removeChild(item)

   @pyqtSlot()    
   def on_actTree_ScanItems_triggered(self): 
      count=self.ui.treeFiles.topLevelItemCount()
      for i in range(count):
         item=self.ui.treeFiles.topLevelItem(i)
         self.__changeItemCaption(item)


   def on_treeFiles_currentItemChanged(self,current,previous):  
      if (current == None):
         return
      nodeType=current.type() 

      if (nodeType==TreeItemType.itTopItem.value):    
         self.ui.actTree_AddFolder.setEnabled(True)
         self.ui.actTree_AddFiles.setEnabled(True)
         self.ui.actTree_DeleteItem.setEnabled(False) 
         self.ui.stackedWidget.setCurrentIndex(0)

      elif (nodeType==TreeItemType.itGroupItem.value):    
         self.ui.actTree_AddFolder.setEnabled(True)
         self.ui.actTree_AddFiles.setEnabled(True)
         self.ui.actTree_DeleteItem.setEnabled(True) 
         
      elif (nodeType==TreeItemType.itInstanceItem.value):     
         self.ui.actTree_AddFolder.setEnabled(False)
         self.ui.actTree_AddFiles.setEnabled(True)
         self.ui.actTree_DeleteItem.setEnabled(True)
         self.__displayInstance(current)   


   @pyqtSlot(bool)  
   def on_actDockFloat_triggered(self,checked):  
      self.ui.dockWidget.setFloating(checked)

   @pyqtSlot(bool)  
   def on_dockWidget_topLevelChanged(self,topLevel): 
      self.ui.actDockFloat.setChecked(topLevel)
        
   @pyqtSlot(bool)  
   def on_actDockVisible_triggered(self,checked): 
      self.ui.dockWidget.setVisible(checked)

   @pyqtSlot(bool) 
   def on_dockWidget_visibilityChanged(self,visible):  
      self.ui.actDockVisible.setChecked(visible)

   
 
if  __name__ == "__main__":        
   app = QApplication(sys.argv)    
   form=QmyMainWindow()            
   form.show()
   sys.exit(app.exec_())