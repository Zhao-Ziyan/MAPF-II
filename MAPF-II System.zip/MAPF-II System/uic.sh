pyuic5 -o ui_MainWindow.py  MainWindow.ui
pyrcc5 res.qrc -o res_rc.py
